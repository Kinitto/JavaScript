let textoimagen = document.getElementById("imagen");
let textoformulario = document.getElementById("formulario");
let textolink = document.getElementById("link");

textoimagen = document.images.length;
imagen.innerHTML = "hay " +textoimagen+" foto";

textolink = document.links.length;
link.innerHTML = "hay " +textolink+" links";

textoformulario = document.forms.length;
formulario.innerHTML = "hay " +textoformulario+" formularios";










