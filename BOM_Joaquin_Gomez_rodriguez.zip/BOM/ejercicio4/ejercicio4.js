console.log("informacion: "+navigator.appVersion);
console.log("cookies: "+navigator.cookieEnabled);
console.log("numero de nucleos de procesador logico usandose: "+navigator.hardwareConcurrency);
console.log("esta el navegador trabajando en linea?: "+navigator.onLine);





