//orientacion de la pantalla
console.log(screen.orientation);
console.log("ancho de la pantalla: "+screen.width)
console.log("alto de la pantalla: "+screen.height)

//metodos utiles: conocer el nivel de brillo de la pantalla del navegador.

//al saber el alto y ancho podemos saber la resolucion y de 
//que manera mostrarle la informacion al usuario.

//saber si tiene una pantalla vertical o horizontal.


