let linkComprobar = document.getElementById("comprobar");
let nombreusuario = document.getElementById("login");
linkComprobar.addEventListener("click",(e)=> {
    e.preventDefault();
    fetch("http://ejercicio1.loc/compruebaDisponibilidad.php")
.then(response => {
    if (response.ok) {
        return response.text();
    }
    return Promise.reject(response);
})
.then(datos =>{
    console.log(datos)
    if (datos =="si"){
        alert("El usuario ha sido registrado");
    }
    else if (datos=="no"){
        alert("El usuario NO ha sido registrado");

    }
})

})
.catch(console.log("Error: " + response.error))




