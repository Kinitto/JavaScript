const login = document.getElementById('login');
const linkComprobar = document.getElementById('comprobar');
let tbody = document.getElementById("lista")

linkComprobar.addEventListener("click",(e)=> {
fetch('http://ejercicio3.loc/compruebaDisponibilidadJSON.php')

.then(response => {  // tenemos los datos en formato JSON, los transformamos en un objeto
  if (response.ok) { // comprobamos que esta dentro de el status 200 y es correcto
    return response.json();
  }
  return Promise.reject(response)  //hacemos que si no es correcto sea reject para que se vaya al catch
})

.then(posts => {      // ya tenemos los datos en _myData_ como un objeto o array  que podemos procesar
  // Aquí procesamos los datos (en nuestro ejemplo los pintaríamos en la tabla)
  tbody.innerHTML = '' // borramos el contenido de la tabla
    const newPost = document.createElement('tr')
    newPost.innerHTML = `
            <td>${JSON.stringify(posts)}</td>
               `
    tbody.appendChild(newPost)
  
    

})
.catch(err => console.error(err));
});
