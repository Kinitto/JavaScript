const login = document.getElementById('login');
const linkComprobar = document.getElementById('comprobar');
const lista = document.getElementById('lista');

linkComprobar.addEventListener("click",(e)=> {
fetch('http://ejercicio2.loc/compruebaDisponibilidadXML.php')
.then(response => {
    if (response.ok) {
        return response.text();
    }
    return Promise.reject(response);
})
.then(datos =>{
    const parser = new DOMParser();
    const xml = parser.parseFromString(datos, "application/xml");
    let frases = xml.getElementsByTagName('disponible');
    for (let i = 0; i < frases.length; i++) {
        let frase = frases[i];
        let fraseList = document.createElement('li');
        fraseList.textContent = frase.textContent;
        if(fraseList.textContent == "si"){
            fraseList.textContent = "Nombre disponible"
            lista.appendChild(fraseList);
        }
        if(fraseList.textContent == "no"){
            fraseList.textContent = "Este nombre NO esta disponible, a continuacion listamos diferentes opciones."
            lista.appendChild(fraseList);
            let opciones = xml.getElementsByTagName('login');
            for (let i = 1; i < opciones.length; i++) {
                let opcion = opciones[i];
                let opcionList = document.createElement('li');
                opcionList.textContent = opcion.textContent;
               
            lista.appendChild(opcionList);
            }
        }
    }
})

.catch(console.log("Error: " + response.error))

});
