function btnAbrir(){

    //crear el body y la tabla, ponerle las lineas finas
    var body = document.body,
    tbl  = document.createElement('table');
    tbl.style.cellpadding="2";
    tbl.style.cellspacing="0"
    //array con las ciudades de la tabla
    const ciudades = ["Almeria", "Cadiz", "Cordoba","Granada","Huelva","Jaen","Malaga","Sevilla"];

    var x = 0;

for(var i = 0; i < 8; i++, x++){
    
    var tr = tbl.insertRow();
    var td = tr.insertCell();
            td.style.border = '1px solid black';
            
            td.appendChild(document.createTextNode(ciudades[x]));

            
    
}

body.appendChild(tbl);
}
